
package com.meeting.room.scheduler.service.impl;

import com.meeting.room.scheduler.entity.Event1;
import com.meeting.room.scheduler.entity.MeetingRoom;
import com.meeting.room.scheduler.model.EventCreateParams;
import com.meeting.room.scheduler.model.EventMoveParams;
import com.meeting.room.scheduler.model.SetColorParams;
import com.meeting.room.scheduler.repository.EventRepository;
import com.meeting.room.scheduler.repository.MeetingRoomRepository;
import com.meeting.room.scheduler.service.MeetingRoomService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MeetingRoomServiceImpl implements MeetingRoomService {

    @Autowired


    private MeetingRoomRepository meetingRoomRepository;

  
    @Autowired
    private EventRepository eventRepository;



    @Override
    public List<MeetingRoom> getAllResources() {
        return (List<MeetingRoom>) meetingRoomRepository.findAll();
    }

    @Override
    public List<Event1> getEvents(LocalDateTime start, LocalDateTime endDate) {
        return eventRepository.findBetween(start, endDate);
    }

    @Override
    @Transactional
    public Event1 createEvent(EventCreateParams eventCreateParams) {
        MeetingRoom r = meetingRoomRepository.findById(eventCreateParams.getResource()).get();

        Event1 e = new Event1();
        e.setStart(eventCreateParams.getStart());
        e.setEnd(eventCreateParams.getEnd());
        e.setText(eventCreateParams.getText());
        e.setResource(r);

        eventRepository.save(e);

        return e;
    }

    @Override
    @Transactional
    public Event1 moveEvent(EventMoveParams eventMoveParams) {
        Event1 event1 = eventRepository.findById(eventMoveParams.getId()).get();
        MeetingRoom r = meetingRoomRepository.findById(eventMoveParams.getResource()).get();

        event1.setStart(eventMoveParams.getStart());
        event1.setEnd(eventMoveParams.getEnd());
        event1.setResource(r);

        eventRepository.save(event1);

        return event1;
    }

    @Override
    @Transactional
    public Event1 setColor(SetColorParams setColorParams) {
        Event1 event1 = eventRepository.findById(setColorParams.getId()).get();
        event1.setColor(setColorParams.getColor());
        eventRepository.save(event1);
        return event1;
    }


}

