
package com.meeting.room.scheduler.service;

import com.meeting.room.scheduler.entity.Event1;
import com.meeting.room.scheduler.entity.MeetingRoom;
import com.meeting.room.scheduler.model.EventCreateParams;
import com.meeting.room.scheduler.model.EventMoveParams;
import com.meeting.room.scheduler.model.SetColorParams;

import java.time.LocalDateTime;
import java.util.List;

public interface MeetingRoomService {

    List<MeetingRoom> getAllResources();
    List<Event1> getEvents(LocalDateTime start, LocalDateTime endDate);
    Event1 createEvent(EventCreateParams eventCreateParams);
    Event1 moveEvent(EventMoveParams eventMoveParams);
    Event1 setColor(SetColorParams setColorParams);
}

