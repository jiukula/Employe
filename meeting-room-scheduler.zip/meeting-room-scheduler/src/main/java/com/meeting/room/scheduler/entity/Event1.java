package com.meeting.room.scheduler.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name="event_info1")
public class Event1 {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	Long id;
	
	String text;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	LocalDateTime start;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	LocalDateTime endDate;
	
	@ManyToOne
	@JsonIgnore
	MeetingRoom resource;

	String color;
	@JsonProperty("resource")
	public Long getResourceId() {
		return resource.getId();
	}
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalDateTime getStart() {
		return start;
	}

	public void setStart(LocalDateTime start) {
		this.start = start;
	}

	public LocalDateTime getEnd() {
		return endDate;
	}

	public void setEnd(LocalDateTime end) {
		this.endDate = end;
	}

	public MeetingRoom getResource() {
		return resource;
	}

	public void setResource(MeetingRoom resource) {
		this.resource = resource;
	}
	public String getColor() { return color; }

	public void setColor(String color) { this.color = color; }
}
