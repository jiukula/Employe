

package com.meeting.room.scheduler.controller;

import java.time.LocalDateTime;
import java.util.List;

import com.meeting.room.scheduler.service.impl.MeetingRoomServiceImpl;
import jakarta.transaction.Transactional;

import com.meeting.room.scheduler.model.EventCreateParams;
import com.meeting.room.scheduler.model.EventMoveParams;
import com.meeting.room.scheduler.model.SetColorParams;

import com.meeting.room.scheduler.entity.Event1;
import com.meeting.room.scheduler.entity.MeetingRoom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MainController {

    @Autowired
    private MeetingRoomServiceImpl meetingRoomService;

    @RequestMapping("/api")
    @ResponseBody
    String home() {
        return "Welcome!";
    }

    @RequestMapping("/api/resources")
    public ResponseEntity<List<MeetingRoom>> resources() {
        List<MeetingRoom> allMeetingRoom = meetingRoomService.getAllResources();
        return ResponseEntity.ok(allMeetingRoom);
    }

    @GetMapping("/api/events")
    public ResponseEntity<List<Event1>> events(@RequestParam("start") LocalDateTime start, @RequestParam("end") LocalDateTime end) {
        List<Event1> allEvents = meetingRoomService.getEvents(start, end);
        return ResponseEntity.ok(allEvents);
    }

    @PostMapping("/api/events/create")
    public ResponseEntity<Event1> createEvent(@RequestBody EventCreateParams eventCreateParams) {
        Event1 event =meetingRoomService.createEvent(eventCreateParams);
        return ResponseEntity.ok(event);
    }

    @PostMapping("/api/events/move")
    public ResponseEntity<Event1> moveEvent(@RequestBody EventMoveParams params) {
        Event1 event = meetingRoomService.moveEvent(params);
        return ResponseEntity.ok(event);
    }

    @PostMapping("/api/events/setColor")
    public ResponseEntity<Event1> setColor(@RequestBody SetColorParams params) {
        Event1 event = meetingRoomService.setColor(params);
        return ResponseEntity.ok(event);
    }
}
