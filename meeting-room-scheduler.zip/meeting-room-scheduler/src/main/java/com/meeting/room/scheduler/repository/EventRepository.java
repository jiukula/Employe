
package com.meeting.room.scheduler.repository;

import java.time.LocalDateTime;
import java.util.List;

import com.meeting.room.scheduler.entity.Event1;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public interface EventRepository extends CrudRepository<Event1, Long> {
	@Query("from Event1 e where not(e.endDate < :from and e.start > :to)")
	public List<Event1> findBetween(@Param("from") LocalDateTime start, @Param("to") @DateTimeFormat(iso=ISO.DATE_TIME) LocalDateTime endDate);
}
