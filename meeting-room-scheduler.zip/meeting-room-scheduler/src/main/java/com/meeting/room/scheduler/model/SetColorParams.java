package com.meeting.room.scheduler.model;


import java.time.LocalDateTime;

public class SetColorParams {
    public Long id;
    public String color;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public SetColorParams(Long id, String color) {
        this.id=id;
        this.color=color;
    }
}
