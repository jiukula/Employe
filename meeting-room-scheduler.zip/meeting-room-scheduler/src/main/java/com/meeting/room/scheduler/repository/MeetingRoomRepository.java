package com.meeting.room.scheduler.repository;

import com.meeting.room.scheduler.entity.MeetingRoom;
import org.springframework.data.repository.CrudRepository;

public interface MeetingRoomRepository extends CrudRepository<MeetingRoom, Long> {
}