package com.meeting.room.scheduler.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
//import com.meeting.room.scheduler.entity.Event;
import com.meeting.room.scheduler.entity.Event1;
import com.meeting.room.scheduler.entity.MeetingRoom;
import com.meeting.room.scheduler.model.EventCreateParams;
import com.meeting.room.scheduler.model.EventMoveParams;
import com.meeting.room.scheduler.model.SetColorParams;
import com.meeting.room.scheduler.service.impl.MeetingRoomServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(MainController.class)
public class MainControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MeetingRoomServiceImpl meetingRoomService;

    @Autowired
    WebApplicationContext webApplicationContext;

    private Event1 event;

    private MeetingRoom meetingRoom;

    @BeforeEach
    public void setUp() {
        meetingRoom = new MeetingRoom();
        meetingRoom.setId(1L);
        meetingRoom.setName("Test_1");

        event = new Event1();
        event.setId(1L);
        event.setColor("green");
        event.setResource(meetingRoom);
        event.setStart(LocalDateTime.now());
        event.setEnd(LocalDateTime.now().plusHours(1));
        event.setText("Arial");
    }

    //write unit test method for resources
    @Test
    public void testResources() throws Exception {
        //create List of MeetingRoom
        List<MeetingRoom> meetingRoomList = new ArrayList<>();
        meetingRoomList.add(meetingRoom);
        //when - thenReturn
        when(meetingRoomService.getAllResources()).thenReturn(meetingRoomList);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/resources").accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    //write unit test method for events
    @Test
    public void testEvents() throws Exception {
        //create List of Events
        List<Event1> events = new ArrayList<>();
        events.add(event);

        //when - thenReturn
        when(meetingRoomService.getEvents(event.getStart(), event.getEnd())).thenReturn(events);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/events")
                        .param("start", event.getStart().toString())
                        .param("end", event.getEnd().toString())
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$",hasSize(1)));
    }

    //write unit test method for createEvent
    @Test
    public void testCreateEvent() throws Exception {
        //when - thenReturn
        when(meetingRoomService.createEvent(any(EventCreateParams.class))).thenReturn(event);

       String data = asJsonString(new EventCreateParams(event.getStart(), event.getEnd(), event.getText()));
        //mockMvc perform
        mockMvc.perform(MockMvcRequestBuilders.post("/api/events/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(data))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    //write unit test method for moveEvent
    @Test
    public void testMoveEvent() throws Exception {
        //when - thenReturn
        when(meetingRoomService.moveEvent(any(EventMoveParams.class))).thenReturn(event);
        EventMoveParams eventMoveParams = new EventMoveParams(event.getId(), event.getStart(), event.getEnd());
        String data = asJsonString(eventMoveParams);

        //mockMvc perform
        mockMvc.perform(MockMvcRequestBuilders.post("/api/events/move")
                .contentType(MediaType.APPLICATION_JSON)
                .content(data))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(eventMoveParams.getId()));

    }

    //write unit test method for setColor
    @Test
    public void testSetColor() throws Exception {
        //when - thenReturn
        when(meetingRoomService.setColor(any(SetColorParams.class))).thenReturn(event);
        SetColorParams setColorParams = new SetColorParams(event.getId(), event.getColor());
        String data = asJsonString(setColorParams);

        //mockMvc perform
        mockMvc.perform(MockMvcRequestBuilders.post("/api/events/setColor")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(data))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(setColorParams.getId()));

    }

    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
