package com.meeting.room.scheduler.service.impl;

//import com.meeting.room.scheduler.entity.Event;
import com.meeting.room.scheduler.entity.Event1;
import com.meeting.room.scheduler.entity.MeetingRoom;
import com.meeting.room.scheduler.repository.EventRepository;
import com.meeting.room.scheduler.repository.MeetingRoomRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class MeetingRoomServiceImplTest {

    @InjectMocks
    private MeetingRoomServiceImpl meetingRoomService;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private MeetingRoomRepository meetingRoomRepository;

    private Event1 event;

    private MeetingRoom meetingRoom;

    @BeforeEach
    public void setUp() {
        meetingRoom = new MeetingRoom();
        meetingRoom.setId(1L);
        meetingRoom.setName("Test_1");

        event = new Event1();
        event.setId(1L);
        event.setColor("green");
        event.setResource(meetingRoom);
        event.setStart(LocalDateTime.now());
        event.setEnd(LocalDateTime.now().plusHours(1));
        event.setText("Arial");
    }

    //write unit test method for getAllResources
    @Test
    void getAllResources() {
        //when-thenReturn
        when(meetingRoomRepository.findAll()).thenReturn(List.of(meetingRoom));
        List<MeetingRoom> meetingRoomList = meetingRoomService.getAllResources();
        assertThat(meetingRoomList).isNotNull();
    }

    //write unit test method for getEvents
    @Test
    void getEvents() {
        //when-thenReturn
        when(eventRepository.findBetween(event.getStart(), event.getEnd())).thenReturn(List.of(event));
        List<Event1> eventList = meetingRoomService.getEvents(event.getStart(), event.getEnd());
        assertThat(eventList).isNotNull();
    }

}
