package com.persistent.usermodule.entity;

//create User entity with table name called User

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name="user_info")
public class User {
    //create field userId, userName, password, emailId, mobileNumber, dob
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userName;
    private String password;
    private String emailId;
    private Long mobileNumber;
    private LocalDate dob;

    //create getter and setter for all the fields
    public Long getId() {
        return id;

    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }


    public Long getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(Long mobileNumber) {
        this.mobileNumber = mobileNumber;
    }


    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

}
