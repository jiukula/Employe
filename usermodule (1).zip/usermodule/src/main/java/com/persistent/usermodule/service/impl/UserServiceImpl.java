package com.persistent.usermodule.service.impl;

import com.persistent.usermodule.entity.User;
import com.persistent.usermodule.repository.UserRepository;
import com.persistent.usermodule.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    //create AutoWired for UserRepository
     @Autowired
    private UserRepository userRepository;

    @Override
    public User getUser(Long id) {
        //fetch User from DB by id
        return userRepository.findById(id).get();
    }

    @Override
    public User addUser(User user) {
        //save User to DB
        return userRepository.save(user);
    }

    @Override
    public User updateUser(User user) {
        //update User to DB
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long id) {
        //delete User from DB
        userRepository.deleteById(id);
    }
}
