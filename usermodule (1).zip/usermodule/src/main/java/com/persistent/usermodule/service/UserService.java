package com.persistent.usermodule.service;

import com.persistent.usermodule.entity.User;

public interface UserService {
    public User getUser(Long id);
    public User addUser(User user);
    public User updateUser(User user);
    public void deleteUser(Long id);
}
