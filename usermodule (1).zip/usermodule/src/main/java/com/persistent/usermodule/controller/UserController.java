package com.persistent.usermodule.controller;

import com.persistent.usermodule.entity.User;
import com.persistent.usermodule.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

//create UserController with RequestMapping and GetMapping
@RestController
@RequestMapping("/api/user")
public class UserController {

    //create AutoWired for UserServiceImpl
    @Autowired
    private UserServiceImpl userService;

    //create get, post, put, delete methods for UserController

    //getting User by id
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id){
           User user= userService.getUser(id);
           //create ResponseEntity for User
        return ResponseEntity.ok(user);
    }

    //posting User
    @PostMapping("/create")
    public ResponseEntity<User> postUser(User user) {
        User user1 = userService.addUser(user);
        //create ResponseEntity for User
        return ResponseEntity.ok(user1);
    }

    //updating User
    @PutMapping("/update")
    public ResponseEntity<User> updateUser(User user) {
        User user1 = userService.updateUser(user);
        //create ResponseEntity for User
        return ResponseEntity.ok(user1);
    }
    //deleting User
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<User> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        //create ResponseEntity for User
        return ResponseEntity.ok().build();
    }
}
