package com.persistent.usermodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration(proxyBeanMethods = false)
public class TestUsermoduleApplication {

	public static void main(String[] args) {
		SpringApplication.from(UsermoduleApplication::main).with(TestUsermoduleApplication.class).run(args);
	}

}
