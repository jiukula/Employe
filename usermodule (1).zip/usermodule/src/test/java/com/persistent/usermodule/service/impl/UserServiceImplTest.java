package com.persistent.usermodule.service.impl;

import com.persistent.usermodule.entity.User;
import com.persistent.usermodule.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserServiceImpl userService;

    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setId(1L);
        user.setPassword("pass123");
        user.setUserName("testName");
        user.setEmailId("test@gmail.com");
        user.setMobileNumber(9788987112L);
    }


    //write unit test method for getUser
    @Test
    public void getUserTest(){
        //when and thenReturn
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        User user1 = userService.getUser(1L);
        assertThat(user1.getId()).isEqualTo(user.getId());
        assertThat(user1.getUserName()).isEqualTo(user.getUserName());
        assertThat(user1.getEmailId()).isEqualTo(user.getEmailId());
        assertThat(user1.getMobileNumber()).isEqualTo(user.getMobileNumber());
        assertThat(user1.getPassword()).isEqualTo(user.getPassword());
    }

    //write unit test method for addUser
    @Test
    public void addUserTest() {
        //when and thenReturn
        when(userRepository.save(user)).thenReturn(user);
        User user1 = userService.addUser(user);
        assertThat(user1.getId()).isEqualTo(user.getId());
        assertThat(user1.getUserName()).isEqualTo(user.getUserName());
        assertThat(user1.getEmailId()).isEqualTo(user.getEmailId());
        assertThat(user1.getMobileNumber()).isEqualTo(user.getMobileNumber());
        assertThat(user1.getPassword()).isEqualTo(user.getPassword());
    }

    //write unit test method for updateUser
    @Test
    public void updateUserTest() {
        //when and thenReturn
        when(userRepository.save(user)).thenReturn(user);
        User user1 = userService.updateUser(user);
        assertThat(user1.getId()).isEqualTo(user.getId());
        assertThat(user1.getUserName()).isEqualTo(user.getUserName());
        assertThat(user1.getEmailId()).isEqualTo(user.getEmailId());
        assertThat(user1.getMobileNumber()).isEqualTo(user.getMobileNumber());
        assertThat(user1.getPassword()).isEqualTo(user.getPassword());
    }

    //write unit test method for deleteUser
    @Test
    public void deleteUserTest() {
        userRepository.delete(user);
        userService.deleteUser(user.getId());
        assertThat("deleted successfully");
    }
}
