package com.persistent.usermodule.controller;

//create Unit tests for UserController

import com.fasterxml.jackson.databind.ObjectMapper;
import com.persistent.usermodule.entity.User;
import com.persistent.usermodule.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;


import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UserController.class)
public class UserControllerTest {
    //Autowired for MockMvc
    @Autowired
    private MockMvc mockMvc;

    private User user;

    //create MockBean for UserServiceImpl
    @MockBean
    private UserServiceImpl userService;

    @BeforeEach
    public void setUp() {
        //create User object for mocking
        user = new User();
        user.setId(1L);
        user.setUserName("testName");
        user.setPassword("pass123");
        user.setEmailId("test@gmail.com");
        user.setMobileNumber(9788987112L);
    }

    //unit test for getUserById
    @Test
    public void getUserById() throws Exception {
        //when and willReturn for getUserById
        when(userService.getUser(user.getId())).thenReturn(user);

        //create mockMvc
        mockMvc.perform(get("/api/user/1"))
                .andExpect(status().isOk())
                .andDo(print())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.password").value("pass123"))
                .andExpect(jsonPath("$.emailId").value("test@gmail.com"))
                .andExpect(jsonPath("$.mobileNumber").value(9788987112L));
    }


    //write unit test method for postUser of UserController
    @Test
    public void postUser() throws Exception {
        //when and willReturn for postUser
        when(userService.addUser(any(User.class))).thenReturn(user);

        ObjectMapper objectMapper = new ObjectMapper();

        //create mockMvc
        mockMvc.perform(post("/api/user/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.password").value("pass123"))
                .andExpect(jsonPath("$.emailId").value("test@gmail.com"))
                .andExpect(jsonPath("$.mobileNumber").value(9788987112L));
    }


    //write unit test method for updateUser of UserController
    @Test
    public void updateUser() throws Exception {
        //when and willReturn for updateUser
        when(userService.updateUser(any(User.class))).thenReturn(user);
        ObjectMapper objectMapper = new ObjectMapper();

        //create mockMvc
        mockMvc.perform(put("/api/user/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.password").value("pass123"))
                .andExpect(jsonPath("$.emailId").value("test@gmail.com"))
                .andExpect(jsonPath("$.mobileNumber").value(9788987112L));
    }

    //write test method for deleteUser of UserController
    @Test
    void deleteUser() throws Exception {
        //invoke method for deleteUser
        userService.deleteUser(user.getId());

        //create mockMvc
        mockMvc.perform(delete("/api/user/delete/{id}",1))
                .andExpect(status().isOk());
    }

}
