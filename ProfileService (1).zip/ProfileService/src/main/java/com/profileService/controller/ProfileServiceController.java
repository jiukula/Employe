package com.profileService.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.profileService.entity.ProfileEntity;
import com.profileService.repository.ProfileServiceRepository;
import com.profileService.service.ProfileService;

@RestController
public class ProfileServiceController {

	@Autowired
	ProfileService profileService;
	
	@Autowired
	ProfileServiceRepository profileServiceRepository;
	
	
	@PostMapping("/save")
	public ResponseEntity<?> addProfile(@RequestBody ProfileEntity profileEntity) {
		 profileService.addProfile(profileEntity);
		return new ResponseEntity<>( HttpStatus.CREATED);
	}

	@GetMapping("/fetch/{empId}")
	public ResponseEntity<?> getProfile(@PathVariable("empId") Long empId) {
		ProfileEntity profile = profileService.findByEmpId(empId);
		System.out.println("profile+++++++++++" + profile);
		return new ResponseEntity<>(profile, HttpStatus.OK);
	}

	@PutMapping("/update/{empId}")
	public ResponseEntity<ProfileEntity> updateProfile(@RequestBody ProfileEntity profileEntity,@PathVariable("empId") Long empId) {
		profileService.updateProfile(profileEntity, empId);
		return new ResponseEntity<ProfileEntity>(profileEntity, HttpStatus.CREATED);
	}

	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteProfile(@PathVariable Long id) {
		 profileService.deleteByEmpId(id);
		return new ResponseEntity<>( HttpStatus.OK);
	}
	
	
	@GetMapping("/viewAll")
	public ResponseEntity<?> viewProfiles() {
		ArrayList<ProfileEntity> profile = (ArrayList<ProfileEntity>) profileService.findAll();
		System.out.println("profile+++++++++++" + profile);
		return new ResponseEntity<ArrayList<ProfileEntity>>(profile,HttpStatus.OK);
	}
	
}
