package com.profileService.response;

public class ProfileServiceResponse {
	
	private long empId;
	private String empName;
	private Integer MobileNo;
	private String userType;
	private String accesType;
	private String emailID;
	
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(Integer mobileNo) {
		MobileNo = mobileNo;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getAccesType() {
		return accesType;
	}
	public void setAccesType(String accesType) {
		this.accesType = accesType;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
	
	public ProfileServiceResponse(long empId, String empName, Integer mobileNo, String userType, String accesType,
			String emailID) {
		super();
		this.empId = empId;
		this.empName = empName;
		MobileNo = mobileNo;
		this.userType = userType;
		this.accesType = accesType;
		this.emailID = emailID;
	}
	
	@Override
	public String toString() {
		return "ProfileServiceResponse [empId=" + empId + ", empName=" + empName + ", MobileNo=" + MobileNo
				+ ", userType=" + userType + ", accesType=" + accesType + ", emailID=" + emailID + "]";
	}
	
	
	

}
