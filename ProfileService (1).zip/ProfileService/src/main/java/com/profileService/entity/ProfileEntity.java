package com.profileService.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Profile_Service")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProfileEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private Long id;
	@Column(name = "emp_id")
	private Long empId;
	@Column(name = "emp_name")
	private String empName;
	@Column(name = "Mobile_no")
	private Long mobileNo;
	@Column(name = "user_type")
	private String userType;
	@Column(name = "access_type")
	private String accessType;
	@Column(name = "email_id")
	private String emailId;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getAccessType() {
		return accessType;
	}
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public ProfileEntity() {
		
	}
	
	public ProfileEntity(Long id, Long empId, String empName, Long mobileNo, String userType, String accesType,
			String emailID) {
		super();
		this.id = id;
		this.empId = empId;
		this.empName = empName;
		this.mobileNo = mobileNo;
		this.userType = userType;
		this.accessType = accesType;
		this.emailId = emailID;
	}
	@Override
	public String toString() {
		return "ProfileEntity [id=" + id + ", empId=" + empId + ", empName=" + empName + ", mobileNo=" + mobileNo
				+ ", userType=" + userType + ", accessType=" + accessType + ", emailId=" + emailId + "]";
	}
	
	

}