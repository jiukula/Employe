package com.profileService.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.profileService.entity.ProfileEntity;
import com.profileService.repository.ProfileServiceRepository;

@Service
public class ProfileService {

	@Autowired
	ProfileServiceRepository profileServiceRepository;
	
	public ProfileEntity addProfile(ProfileEntity profileEntity) {
		return profileServiceRepository.save(profileEntity);

	}


	public ProfileEntity findByEmpId(Long empId) {
		return profileServiceRepository.findByEmpId(empId);

	}
	
	public ArrayList<ProfileEntity> findAll() {
		return (ArrayList<ProfileEntity>) profileServiceRepository.findAll();

	}

	
	
	public void deleteByEmpId(Long id) {
		 profileServiceRepository.deleteById(id);

	}
	
	public ProfileEntity updateProfile(ProfileEntity profileEntity,Long empId) {
		ProfileEntity	existingProfile = profileServiceRepository.findByEmpId(empId);
		
		existingProfile.setEmailId(profileEntity.getEmailId());
		existingProfile.setEmpId(profileEntity.getEmpId());
		existingProfile.setEmpName(profileEntity.getEmpName());
		existingProfile.setMobileNo(profileEntity.getMobileNo());
		existingProfile.setUserType(profileEntity.getUserType());
		existingProfile.setAccessType(profileEntity.getAccessType());
		
		ProfileEntity updatedProfile = profileServiceRepository.save(existingProfile);
		System.out.println("updatedProfile"+updatedProfile);
		return profileServiceRepository.save(updatedProfile);

	}
}
