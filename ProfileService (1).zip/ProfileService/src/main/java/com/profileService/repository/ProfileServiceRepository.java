package com.profileService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.profileService.entity.ProfileEntity;

@Repository
public interface ProfileServiceRepository extends JpaRepository<ProfileEntity,Long> {


	public ProfileEntity findByEmpId(Long empId);
	
}
