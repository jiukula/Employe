package com.persistent.leavesystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.io.FileNotFoundException;
import java.time.LocalDateTime;

@RestControllerAdvice
public class EmployeePlannedLeavesControllerAdvice {
    @ExceptionHandler(FileNotFoundException.class)
    public ResponseEntity<EmployeePlannedLeavesException> handlerFileNotFoundException(FileNotFoundException exception,
                                                                                WebRequest webRequest) {
        EmployeePlannedLeavesException employeePortalException = new EmployeePlannedLeavesException("FILE_NOT_FOUND",
                exception.getMessage(), LocalDateTime.now());
        return new ResponseEntity<>(employeePortalException, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<EmployeePlannedLeavesException> handlerGlobalException(Exception exception, WebRequest webRequest) {
        EmployeePlannedLeavesException employeePortalException = new EmployeePlannedLeavesException("INTERNAL_SERVER_ERROR",
                " Due to field error(s) in Email", LocalDateTime.now());
        return new ResponseEntity<>(employeePortalException, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
