package com.persistent.leavesystem;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@Disabled
@SpringBootTest
class EmployeePlannedLeavesManagementSystemApplicationTests {
	// generate test cases for the application
	@Test
	void contextLoads() {
		// generate test cases
	}
}
